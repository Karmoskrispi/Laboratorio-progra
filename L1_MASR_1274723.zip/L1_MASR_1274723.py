'''variable1 = 21000  
print  ("comentario")
print (type(variable1), end="")

variable1 = "hola"
print(variable1)
print(type(variable1), end="")'''

print("ingrese su nombre: ")
nombre = input()
print("hola mundo")
print("soy "+ nombre) 

#print("hola mundo soy Marcos") 

#print("hola mundo")
#print ("soy marcos")

#la diferencia entre estas dos es que sin el "end" se escribe en lineas diferentes y con "end" se escribe en la misma linea

#print("hola mundo", end="")
#print(" soy marcos", end="")'''
#texto = input()
#print(texto + " hola")

